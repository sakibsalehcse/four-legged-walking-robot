package coppelia;

public class CharW
{
    char w;

    public CharW(char c)
    {
        w = c;
    }

    public void setValue(char c)
    {
        w = c;
    }

    public char getValue()
    {
        return w;
    }
}